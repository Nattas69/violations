<!--Изменение статуса заявления-->
<?php
/*подтвердить*/
if(isset($_POST['confirm'])) {   
$confirm = $_POST["confirm"];

$sql_edit = "SELECT * FROM `statements`";
if($rez = $link->query($sql_edit)) {  

$sql_edit = "UPDATE `statements` SET status = 'подтверждено' WHERE id = '$confirm'";
if($link->query($sql_edit)) {      
echo "<script>alert(\"Заявление подтверждено\");</script>";
}

$page = $_SERVER['REQUEST_URI'];
echo '<script type="text/javascript">';
echo 'window.location.href="'.$page.'";';
echo '</script>';}}

/*отклонить*/
if(isset($_POST['reject'])) {   
$reject = $_POST["reject"];

$sql_edit = "SELECT * FROM `statements`";
if($rez = $link->query($sql_edit)) {  

$sql_edit = "UPDATE `statements` SET status = 'отклонено' WHERE id = '$reject'";

if($link->query($sql_edit)) {      
echo "<script>alert(\"Заявление отклонено\");</script>";
}

$page = $_SERVER['REQUEST_URI'];
echo '<script type="text/javascript">';
echo 'window.location.href="'.$page.'";';
echo '</script>';}}
?>