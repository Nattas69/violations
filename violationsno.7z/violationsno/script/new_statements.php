<!--Вывод новых заявлений-->
<?php 
$sql_user = "SELECT * FROM `statements` WHERE status = 'новое'";
if($result = $link->query($sql_user)) {
     
foreach($result as $row) {
$user = $row['user'];
$car_number = $row['car_number'];
$violation = $row['violation'];  
$status = $row['status']; 
$id = $row['id']; 

print("
<tr>
<td><p>$user</p></td>
<td><p>$car_number</p></td>
<td><p>$violation </p></td>
<td>
<button name='confirm' value='$id'>Подтвердить</button> <br>
<button name='reject' value='$id'>Отклонить</button>
</td>
</tr>
");
}

$check = mysqli_num_rows($result);
if($check == 0) {print("<td colspan='4'><p id='empty'>Заявлений нет</p></td>");}  
}
?> 