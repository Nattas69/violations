<!--Вывод всех заявлений из БД-->
<?php 
$sql_user = "SELECT * FROM `statements`";
if($result = $link->query($sql_user)) {
     
foreach($result as $row) {
$user = $row['user'];
$car_number = $row['car_number'];
$violation = $row['violation'];  
$status = $row['status']; 
$id = $row['id']; 

print("
<tr>
<td><p>$user</p></td>
<td><p>$car_number</p></td>
<td><p>$violation </p></td>
<td><p>$status</p></td>
</tr>
");
}}
?>