<!--Получение и вывод данных пользователя из БД-->
<?php 
$users = $_SESSION['login'];

$sql_user = "SELECT * FROM `users`";
if($result = $link->query($sql_user)) {
    
foreach($result as $row) {
$FIO = $row['FIO'];
$phone = $row['phone'];
$email = $row['email'];  
$login = $row['login']; 

if ($users == $login) {
print("<div class='user_card'>
<div class='center'><div class='user'>
<img src='../img/user.png'>
<p>Пользователь: $FIO</p>
</div></div>

<div class='user'>
<p>Email: $email</p>
<p>Телефон: $phone</p>
</div>

<div class='user'>
<p>Логин: $login</p>
<p>Статус: пользователь</p>
</div>
</div>");
}}}
?> 