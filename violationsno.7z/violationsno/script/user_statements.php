<!--Вывод заявлений (для конкретного пользователя)-->
<?php 
$FIO = $_SESSION['FIO'];

$sql_user = "SELECT * FROM `statements` WHERE user = '$FIO'";
if($result = $link->query($sql_user)) {
   
$check = mysqli_num_rows($result);
if($check == 0) {print("<p id='empty'>Заявлений нет</p>");}    

foreach($result as $row) {
$user = $row['user'];
$car_number = $row['car_number'];
$violation = $row['violation'];  
$status = $row['status']; 

if ($user == $FIO) {
print("
<div class='user'>
<p>Номер автомобиля: $car_number</p>
<p>Нарушение: $violation </p>
<p>Статус: $status </p>
</div>
");
}}}
?> 