<!--Занести заявление пользователя в БД-->
<?php
if(isset($_POST['statements'])) {    
$car = $_POST["car"];
$violation = $_POST["violation"];
$users = $_SESSION['FIO'];

if($violation == ' ') {echo "<script>alert(\"Ошибка! Пустое поле нарушения\");</script>"; }

else {
$sql_reg = "INSERT INTO `statements` (user, car_number, violation, status) 
VALUES ('$users', '$car', '$violation', 'новое')";
}

if($link->query($sql_reg)) {      
echo "<script>alert(\"Заявление принято\");</script>";
}

$page = $_SERVER['REQUEST_URI'];
echo '<script type="text/javascript">';
echo 'window.location.href="'.$page.'";';
echo '</script>';}
?>