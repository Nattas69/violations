<!--Вход в систему-->
<?php
if(isset($_SESSION['login'])) {
echo "<script>const button = document.getElementById('entry'); button.click();</script>";
}
?>