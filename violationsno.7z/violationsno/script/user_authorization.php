<!--Авторизация-->
<?php
if(isset($_POST['entry'])) { 
$login = $_POST["login"];
$pass = $_POST["pass"];

$sql_logon = "SELECT * FROM `users`";
if($result = $link->query($sql_logon)) {
foreach($result as $row) {
$bd_login = $row['login'];
$bd_pass = $row['password'];
$status = $row['status'];
$FIO = $row['FIO'];

if($bd_login == $login && $bd_pass == $pass && $status == 'user')  {
$_SESSION['login'] = $login;
$_SESSION['pass'] = $pass;
$_SESSION['FIO'] = $FIO;

/*переход на профиль пользователя*/    
$new_url = 'profile.php'; 
header('Location: '.$new_url);
}

else if($bd_login == $login && $bd_pass == $pass && $status == 'adm')  {
$_SESSION['login'] = $login;
$_SESSION['pass'] = $pass;

/*переход на профиль админа*/    
$new_url = 'adm.php'; 
header('Location: '.$new_url);
}}

if($bd_login != $login || $bd_pass != $pass) {echo "<script>alert(\"Неверный логин или пароль!\");</script>";}
}}
?>