<!--Выход из системы (завершение сессии)-->
<?php 
if(isset($_POST['exit'])) {  
unset($_SESSION["login"]);
unset($_SESSION["pass"]);
$new_url = 'authorization.php'; 
header('Location: '.$new_url);
}
?>