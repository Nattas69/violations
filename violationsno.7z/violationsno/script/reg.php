<!--Регистрация-->
<?php
if(isset($_POST['reg'])) {    
$FIO = $_POST["FIO"];
$phone = $_POST["phone"];
$email = $_POST["email"];
$login = $_POST["login"]; 
$pass = $_POST["pass"]; 
$pass_replace = $_POST["pass_replace"]; 

$sql_reg_user = "SELECT * FROM `users` WHERE login = '$login'";
if($rez = $link->query($sql_reg_user)) {  

foreach($rez as $row) {
$checklogin = $row['login']; 
}

if ($checklogin == $login) {
echo "<script>alert(\"Выбранный вами логин занят\");</script>";
}

else if ($pass != $pass_replace) {
echo "<script>alert(\"Пароли не совпадают\");</script>";
}

else {
$sql_reg = "INSERT INTO `users` (FIO, phone, email, login, password, status) 
VALUES ('$FIO', '$phone', '$email', '$login', '$pass', 'user')";

if($link->query($sql_reg)) {      
echo "<script>alert(\"Регистрация прошла успешно\");</script>";
}}

$page = $_SERVER['REQUEST_URI'];
echo '<script type="text/javascript">';
echo 'window.location.href="'.$page.'";';
echo '</script>';}}
?>