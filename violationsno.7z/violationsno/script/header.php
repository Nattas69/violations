<!--Шапка-->   
<div class="header">
<a href="../index.html" class="logo"><img src="../img/logo.png"></a>
<div class="header-right">
<a href="../index.html"><b>Главная</b></a> 
<a href="../index.html#about_us"><b>О нас</b></a> 
<a href="authorization.php"><b>Профиль</b></a>    
</div>
</div>