<!--Подключение к БД-->
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name = 'violationsno';
$link = mysqli_connect($host, $user, $pass, $name); 
error_reporting(E_ERROR | E_PARSE);
?>