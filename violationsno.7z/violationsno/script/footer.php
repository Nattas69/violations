<!--Подвал-->   
<div class="footer_card">
<div class="footer">
<p>Контакты:</p>
<p>+7 (951)-234-67-84</p>
<p>ViolationsNo@gmail.com</p>
</div>

<div class="footer">
<img src="../img/logo.png">
<p><b>Нарушениям.Нет</b></p>
</div>

<div class="footer">
<p>Навигация:</p>
<a href="../index.html"><p>Главная</p></a>
<a href="authorization.php"><p>Профиль</p></a>
</div>
</div>