<?php 
session_start();
?>

<html>
<head>
<meta charset="utf-8"/>    
<link rel="icon" href="../img/logo.png"/>       
<title>Нарушениям.Нет</title>  
<link rel="stylesheet" href="../style/style.css"/>    
<link rel="stylesheet" href="../style/media.css"/>   
</head>

<body>
<!--Подключение БД и Шапки-->  
<?php include '../script/database.php';?>
<?php include '../script/header.php';?>

<!--Название страницы-->   
<form action="" method="post">
<div class="title"><h1>Профиль</h1>  
<button name ="exit">Выйти из профиля</button> 
</div>
</form>

<!--Выход из профиля (завершение сессии)-->   
<?php include '../script/exit.php';?>

<form action="" method="post">
<div class="profile">
<!--Данные пользователя-->   
<?php include '../script/user.php';?>
</div>
</form>

<!--Переход на другие страницы-->   
<div class="statement">
<a href="statements.php"><button>Посмотреть заявления</button></a> <br/>    
<a href="create_statement.php"><button>Сформировать заявление</button></a>    
</div>

<!--Подключение Подвала-->  
<?php include '../script/footer.php';?>
</body>
</html>