<?php 
session_start();
?>

<html>
<head>
<meta charset="utf-8"/>    
<link rel="icon" href="../img/logo.png"/>       
<title>Нарушениям.Нет</title>  
<link rel="stylesheet" href="../style/style.css"/>  
<link rel="stylesheet" href="../style/media.css"/>     
</head>

<body>
<!--Подключение БД и Шапки-->  
<?php include '../script/database.php';?>
<?php include '../script/header.php';?>

<!--Форма авторизации-->  
<form action="authorization.php" method="post">
<div class="form_container">      
<div class="form">  
<a href="../index.html"><img src="../img/logo.png"/></a> <h2>Авторизация</h2> 
<input type="text" id="login" name = "login" placeholder="Введите логин" required value = "<?php echo $_SESSION['login'];?>"/> <br/>
<input type="password" id="pass" name = "pass" class="input" placeholder="Введите пароль" required value = "<?php echo $_SESSION['pass'];?>"/> <br/>
<button class="button" id="entry" name="entry">Войти</button> <br/>  
<a href="registration.php">зарегистрироваться</a>
</div>
</div>
</form>

<!--Вход в систему-->  
<?php include '../script/logon.php';?>

<!--Авторизация-->  
<?php include '../script/user_authorization.php';?>

<!--Подключение Подвала-->  
<?php include '../script/footer.php';?>
</body>
</html>