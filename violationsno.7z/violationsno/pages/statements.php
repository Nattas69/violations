<?php 
session_start();
?>

<html>
<head>
<meta charset="utf-8"/>    
<link rel="icon" href="../img/logo.png"/>       
<title>Нарушениям.Нет</title>  
<link rel="stylesheet" href="../style/style.css"/>    
<link rel="stylesheet" href="../style/media.css"/>   
</head>

<body>
<!--Подключение БД и Шапки--> 
<?php include '../script/database.php';?>
<?php include '../script/header.php';?>


<div class="title"><h1>Заявления
<br/><a href="profile.php">назад</a>
</h1></div>

<form action="" method="post">
<div class="profile">
<div class='user_card'>
<!--Заявления пользователя--> 
<?php include '../script/user_statements.php';?>
</div>
</div>
</form>

<!--Переход на другую страницу--> 
<div class="statement"> 
<a href="create_statement.php"><button>Сформировать заявление</button></a>    
</div>

<!--Подключение Подвала--> 
<?php include '../script/footer.php';?>
</body>
</html>