<?php 
session_start();
?>

<html>
<head>
<meta charset="utf-8"/>    
<link rel="icon" href="../img/logo.png"/>       
<title>Нарушениям.Нет</title>  
<link rel="stylesheet" href="../style/style.css"/>    
<link rel="stylesheet" href="../style/media.css"/>   
</head>

<body>
<!--Подключение БД и Шапки-->  
<?php include '../script/database.php';?>
<?php include '../script/header.php';?>

<!--Форма для заполнения-->
<form action="create_statement.php" method="post">
<div class="form_container">      
<div class="form">  
<h2>Сформировать заявление</h2>
<input name="car" type="text" placeholder="Введите номер машины" 
minlength="8" maxlength="9"  required pattern="[a-zA-Z0-9]+"/><br/>
<textarea id="violation" name="violation" placeholder="Опишите нарушение"
cols="22" rows="2" required></textarea> <br/>
<button name="statements">Отправить</button> <br/>
<a href="profile.php">назад</a>
</div>
</div>
</form>

<!--Отправить заявление-->
<?php include '../script/create_statement_user.php';?>

<!--Подключение Подвала-->  
<?php include '../script/footer.php';?>
</body>
</html>