<?php 
session_start();
?>

<html>
<head>
<meta charset="utf-8"/>    
<link rel="icon" href="../img/logo.png"/>       
<title>Нарушениям.Нет</title>  
<link rel="stylesheet" href="../style/style.css"/> 
<link rel="stylesheet" href="../style/media.css"/>      
</head>

<body>
<!--Подключение БД и Шапки-->     
<?php include '../script/database.php';?>
<?php include '../script/header.php';?>

<!--Форма регистрации-->
<form action="registration.php" method="post">
<div class="form_container_reg">      
<div class="form">  
<a href="../index.html"><img src="../img/logo.png" title = "На главную"/></a> <h2>Регистрация</h2>

<input name="FIO" type="text" 
placeholder="Введите ФИО" required pattern="[а-яА-Я ]+"/><br/>

<input name="phone" type="tel"
placeholder="+7(XXX)-XXX-XX-XX" required pattern="[+]{1}[0-9]{11,14}"/> <br/>

<input name="email" type="email" 
placeholder="Введите email" required pattern="[a-zA-Zа-яА-Я.@0-9]+"/> <br/>

<input name = "login" type="text" 
placeholder="Придумайте логин" required pattern="[a-zA-Zа-яА-Я0-9]+"/><br/>

<input name = "pass"  type="password" minlength="6" 
placeholder="Придумайте пароль" required pattern="[a-zA-Zа-яА-Я0-9]+"/><br/>

<input name = "pass_replace" type="password" minlength="6" 
placeholder="Повторите пароль" required pattern="[a-zA-Zа-яА-Я0-9]+"/><br/>

<button name="reg">Зарегистрироваться</button> <br/>
<a href="authorization.php">войти</a>
</div>
</div>
</form>

<!--Регистрация-->
<?php include '../script/reg.php';?>

<!--Подключение Подвала-->
<?php include '../script/footer.php';?>
</body>
</html>