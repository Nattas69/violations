<?php 
session_start();
?>

<html>
<head>
<meta charset="utf-8"/>    
<link rel="icon" href="../img/logo.png"/>       
<title>Нарушениям.Нет</title>  
<link rel="stylesheet" href="../style/style.css"/>    
<link rel="stylesheet" href="../style/media.css"/>   
</head>

<body>
<!--Подключение БД и Шапки-->    
<?php include '../script/database.php';?>
<?php include '../script/header.php';?>

<!--Название страницы-->    
<form action="" method="post">
<div class="title"><h1>Панель администратора</h1>  
<button name ="exit">Выход</button> 
</div>
</form>

<!--Выход из профиля (завершение сессии)-->   
<?php include '../script/exit.php';?>

<h1 id="heading">Новые заявления</h1>
<form action="" method="post">
<table class="user_statements">
<tr>
<td><p>Отправитель</p></td>
<td><p>Номер автомобиля</p></td>
<td><p>Нарушение</p></td>
<td><p>Статус</p></td>
</tr>
<!--Вывод новых заявлений-->  
<?php include '../script/new_statements.php';?>
</table>
</form>

<!--Изменение статуса заявления--> 
<?php include '../script/change_status.php';?>

<h1 id="heading">Все заявления</h1>
<form action="" method="post">
<table class="user_statements">
<tr>
<td><p>Отправитель</p></td>
<td><p>Номер автомобиля</p></td>
<td><p>Нарушение</p></td>
<td><p>Статус</p></td>
</tr>
<!--Вывод всех заявлений--> 
<?php include '../script/all_statements.php';?> 
</table>
</form>

<!--Подключение подвала--> 
<?php include '../script/footer.php';?>
</body>
</html>